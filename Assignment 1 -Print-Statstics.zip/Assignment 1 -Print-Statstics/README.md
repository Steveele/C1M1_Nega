
/* Author : Estifanos Nega*/
 project detail: This is a week 1 programming  project for Emnedded Systems. It includes some basic function to compute mean , median , max , min and sort an array >
 */
